<?php

$conn = mysqli_connect("localhost", "root", "", "login_register") or die ("Connection failed");

?>