<?php
    // $hostName = "localhost";
    // $dbUser = "root";
    // $dbPassword = "";
    // $dbName = "authenticate";

    // $conn=mysqli_connect($hostName, $dbUser, $dbPassword, $dbName);
    // if(!$conn){
    //     die("Something went wrong!" . mysqli_connect_error());
    // }

    $hostName = "localhost";
    $dbUser = "root";
    $dbPassword = "";
    $dbName = "login_register";

    // Create a database if not exists
    $conn = mysqli_connect($hostName, $dbUser, $dbPassword);
    if(!$conn){
        die("Something went wrong!" . mysqli_connect_error());
    }

    // Create a Database if not exists
    $sql = "CREATE DATABASE IF NOT EXISTS $dbName";
    $databaseCreated = false;
    if(mysqli_query($conn, $sql)){
        // echo "Database Created Successfully";
        $databaseCreate = mysqli_affected_rows($conn) > 0;
    }
    //  else {
    //     die("Error Creating database". mysqli_error($conn));
    // }

    // Connect to the database
    mysqli_select_db($conn, $dbName);

    // SQL to Create users table if doesn't exists
    $createTable = "
        CREATE TABLE IF NOT EXISTS users (
            id INT(11) AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(100) NOT NULL,
            email VARCHAR(255) NOT NULL,
            password VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    ";
    $tableCreated = false;

    if(mysqli_query($conn, $createTable)){
        // echo "Table 'users' is ready";
        $tableCreated = mysqli_affected_rows($conn)>0;
    } 
    // else {
    //     die("Error Creating table". mysqli_error($conn));
    // }
    if($databaseCreate){
        echo "database created successfully";
    } elseif($tableCreated){
        echo "table created successfully";
    }
?>